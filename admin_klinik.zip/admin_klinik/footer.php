	<style>
	footer {
	clear:both;
	background-color:#080808;
	padding:8px;
	color:#eee;
	}
	</style>
	<footer>
		<p>&copy; | Imamfauzi 2022 |</p>
	</footer>